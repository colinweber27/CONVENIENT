Citation:

@Article{Horn:2008qv,
     author    = "Horn, I. and others",
 collaboration = "CB-ELSA",
     title     = "{Study of the reaction $\gamma p\to p\pi^0\eta$}",
     journal   = "Eur. Phys. J.",
     volume    = "A38",
     year      = "2008",
     pages     = "173-186",
     eprint    = "0806.4251",
     archivePrefix = "arXiv",
     primaryClass  =  "nucl-ex",
     doi       = "10.1140/epja/i2008-10657-7",
     SLACcitation  = "%%CITATION = 0806.4251;%%"
}

*****************************************************
Data file includes:

Column 1: W [GeV]
Column 2: Xsection for gamma p -> p pi^0 eta [mu b]

